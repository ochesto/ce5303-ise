Por Ernesto Ulate.

### Compilar las bibliotecas y el programa de prueba mediante:

    make

### Ejecutar aplicaciones de prueba:

#### Programa con biblioteca estática

    bin/calculadora_e

#### Programa con biblioteca estática

    bin/calculadora_d

##### Recuerde establecer la variable de entorno mediante:

    export LD_LIBRARY_PATH=$(pwd)/lib
