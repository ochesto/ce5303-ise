
#ifndef _BIBLIOTECA_H
#define _BIBLIOTECA_h

int lib_suma (int p_a, int p_b);
int lib_resta (int p_a, int p_b);
int lib_multiplicacion (int p_a, int p_b);
int lib_division (int p_a, int p_b);
double lib_raiz_cuadrada (int p_a);

#endif

